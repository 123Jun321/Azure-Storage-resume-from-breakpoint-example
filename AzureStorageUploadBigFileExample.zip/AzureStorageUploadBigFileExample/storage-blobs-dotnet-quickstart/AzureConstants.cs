﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AzureStorageUploadBigFileExample
{
	internal class AzureConstants
	{
		//存储账户
		public static string Account = "guanjunstorage";

		//存储密码
		public static string SecretKey = "IORRlrxprU0p8gSBaXzPzaTAoeu722Nvp6sjckdz1s3/6DmcFdQDmsOmbRtyW/GpoETWNvBfd50/C6Jl5oRXyg==";

		public static string SharedKeyAuthorizationScheme = "SharedKey";
	}
}