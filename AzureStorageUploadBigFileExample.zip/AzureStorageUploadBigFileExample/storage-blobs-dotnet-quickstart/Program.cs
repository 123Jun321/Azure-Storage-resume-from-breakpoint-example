﻿//------------------------------------------------------------------------------
//MIT License

//Copyright(c) 2017 Microsoft Corporation. All rights reserved.

//Permission is hereby granted, free of charge, to any person obtaining a copy
//of this software and associated documentation files (the "Software"), to deal
//in the Software without restriction, including without limitation the rights
//to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
//copies of the Software, and to permit persons to whom the Software is
//furnished to do so, subject to the following conditions:

//The above copyright notice and this permission notice shall be included in all
//copies or substantial portions of the Software.

//THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
//AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
//LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
//OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
//SOFTWARE.
//------------------------------------------------------------------------------

namespace AzureStorageUploadBigFileExample
{
	using Microsoft.WindowsAzure.Storage;
	using Microsoft.WindowsAzure.Storage.Blob;
	using System;
	using System.Collections.Generic;
	using System.IO;
	using System.Text;
	using System.Threading.Tasks;

	using System;

	using System.Collections;
	using System.Collections.Specialized;
	using System.Globalization;

	using System.IO;

	using System.Net;

	using System.Text;

	using System.Web;
	using System.Security.Cryptography;

	/// <summary>
	/// Azure Storage Quickstart Sample - Demonstrate how to upload, list, download, and delete blobs.
	///
	/// Note: This sample uses the .NET asynchronous programming model to demonstrate how to call Blob storage using the
	/// storage client library's asynchronous API's. When used in production applications, this approach enables you to improve the
	/// responsiveness of your application. Calls to Blob storage are prefixed by the await keyword.
	///
	/// Documentation References:
	/// - Azure Storage client library for .NET - https://docs.microsoft.com/dotnet/api/overview/azure/storage?view=azure-dotnet
	/// - Asynchronous Programming with Async and Await - http://msdn.microsoft.com/library/hh191443.aspx
	/// </summary>

	public static class Program
	{
		public static void Main()
		{
			Console.WriteLine("Azure Blob storage - .NET Quickstart sample");
			Console.WriteLine();
			//ProcessAsync().GetAwaiter().GetResult();
			//uploadBigFile().GetAwaiter().GetResult();
			string uri = string.Concat("https://", AzureConstants.Account, ".blob.core.chinacloudapi.cn/");//注意正确修改指向中国版Azure的终结点

			string sourcePath = @"C:\Users\guan.jun\Desktop\6.mkv";
			int bufferSize = 1024 * 1024 * 2;
			string flagFile = Path.GetFileNameWithoutExtension(sourcePath) + ".txt";
			int fileSize = File.ReadAllBytes(sourcePath).Length;
			string contentHash = md5()(File.ReadAllBytes(sourcePath));

			int fileCount = fileSize / bufferSize + 1;
			int currentCount = 0;
			byte[] buffer = new byte[bufferSize];
			List<string> blobIdList = new List<string>();
			//设置单个块 Blob 的大小（分块方式）
			if (!File.Exists(flagFile)) {
				FileStream fs = File.Create(flagFile);
				fs.Close();
				fs.Dispose();
			}
			else {
				string[] blobIds = File.ReadAllLines(flagFile);
				currentCount = blobIds.Length;
				blobIdList.AddRange(blobIds);
			}
			BlobHelper helper = new BlobHelper("BlockBlob", uri);
			try {
				for (int i = currentCount; i < fileCount; i++) {
					using (FileStream fs = new FileStream(sourcePath, FileMode.Open, FileAccess.Read, FileShare.Read, bufferSize)) {
						fs.Read(buffer, 0, buffer.Length);
					}
					string blobId = Convert.ToBase64String(Encoding.UTF8.GetBytes(Guid.NewGuid().ToString()));
					helper.PutBlobAsync("test", "7", buffer, blobId).GetAwaiter().GetResult(); //put blob
					Console.WriteLine("Put blob success!");
					blobIdList.Add(blobId);
					File.AppendAllLines(flagFile, new List<string>() { blobId });
				}
				helper.PutBlobListAsync("test", "7", blobIdList, contentHash).GetAwaiter().GetResult();
			}
			catch (Exception e) {
				Console.WriteLine(e.Message);
			}

			Console.WriteLine("Press any key to exit the sample application.");
			Console.ReadLine();
		}

		private static async Task ProcessAsync()
		{
			CloudStorageAccount storageAccount = null;
			CloudBlobContainer cloudBlobContainer = null;
			string sourceFile = null;
			string destinationFile = null;

			// Retrieve the connection string for use with the application. The storage connection string is stored
			// in an environment variable on the machine running the application called storageconnectionstring.
			// If the environment variable is created after the application is launched in a console or with Visual
			// Studio, the shell needs to be closed and reloaded to take the environment variable into account.
			string storageConnectionString = "DefaultEndpointsProtocol=https;AccountName=guanjunfunctionac52;AccountKey=eTQ52ylTRq5sZNHELMggX4qofji2rk2mVhsK0veGA3mGyIOdBPW4TebY4pMr3NHJc+f4KY3F2sumXFcZ9VSAXg==;EndpointSuffix=core.chinacloudapi.cn";

			// Check whether the connection string can be parsed.
			if (CloudStorageAccount.TryParse(storageConnectionString, out storageAccount)) {
				try {
					// Create the CloudBlobClient that represents the Blob storage endpoint for the storage account.
					CloudBlobClient cloudBlobClient = storageAccount.CreateCloudBlobClient();

					// Create a container called 'quickstartblobs' and append a GUID value to it to make the name unique.
					cloudBlobContainer = cloudBlobClient.GetContainerReference("test");

					// Set the permissions so the blobs are public.

					CloudBlockBlob cloudBlockBlob = cloudBlobContainer.GetBlockBlobReference("deploy.json");
					await cloudBlockBlob.UploadFromFileAsync(@"C:\Users\guan.jun\Desktop\about case\deploy.json", null, new BlobRequestOptions() { StoreBlobContentMD5 = true, }, null);

					// List the blobs in the container.
					Console.WriteLine("Listing blobs in container.");
					BlobContinuationToken blobContinuationToken = null;
					do {
						var resultSegment = await cloudBlobContainer.ListBlobsSegmentedAsync(null, blobContinuationToken);
						// Get the value of the continuation token returned by the listing call.
						blobContinuationToken = resultSegment.ContinuationToken;
						foreach (IListBlobItem item in resultSegment.Results) {
							Console.WriteLine(item.Uri);
						}
					} while (blobContinuationToken != null); // Loop while the continuation token is not null.
					Console.WriteLine();
				}
				catch (StorageException ex) {
					Console.WriteLine("Error returned from the service: {0}", ex.Message);
				}
				finally {
				}
			}
			else {
				Console.WriteLine(
					"A connection string has not been defined in the system environment variables. " +
					"Add a environment variable named 'storageconnectionstring' with your storage " +
					"connection string as a value.");
			}
		}

		public static async Task uploadBigFile()
		{
			//设置请求选项
			BlobRequestOptions requestoptions = new BlobRequestOptions() {
				UseTransactionalMD5 = true,
				StoreBlobContentMD5 = true
			};
			BlobRequestOptions requestoptions2 = new BlobRequestOptions() {
				StoreBlobContentMD5 = true
			};
			CloudStorageAccount account = CloudStorageAccount.Parse("DefaultEndpointsProtocol=https;AccountName=guanjunstorage;AccountKey=IORRlrxprU0p8gSBaXzPzaTAoeu722Nvp6sjckdz1s3/6DmcFdQDmsOmbRtyW/GpoETWNvBfd50/C6Jl5oRXyg==;EndpointSuffix=core.chinacloudapi.cn");
			CloudBlobClient blobclient = account.CreateCloudBlobClient();
			int bufferSize = 1024 * 1024 * 10;
			//设置客户端默认请求选项
			blobclient.DefaultRequestOptions = requestoptions;
			CloudBlobContainer blobcontainer = blobclient.GetContainerReference("test");
			//文件路径，文件大小 117MB
			string sourcePath = @"C:\Users\guan.jun\Desktop\6.mkv";
			string flagFile = Path.GetFileNameWithoutExtension(sourcePath) + ".txt";
			int fileSize = File.ReadAllBytes(sourcePath).Length;
			int fileCount = fileSize / bufferSize + 1;
			int currentCount = 0;
			byte[] buffer = new byte[bufferSize];
			List<string> blobIdList = new List<string>();
			CloudBlockBlob blockblob = blobcontainer.GetBlockBlobReference("6.mkv");
			//设置单个块 Blob 的大小（分块方式）
			if (!File.Exists(flagFile)) {
				FileStream fs = File.Create(flagFile);
				fs.Close();
				fs.Dispose();
			}
			else {
				string[] blobIds = File.ReadAllLines(flagFile);
				currentCount = blobIds.Length;
				blobIdList.AddRange(blobIds);
			}
			try {
				for (int i = currentCount; i < fileCount; i++) {
					using (FileStream fs = new FileStream(sourcePath, FileMode.Open, FileAccess.Read, FileShare.Read, bufferSize)) {
						fs.Read(buffer, 0, buffer.Length);
					}
					using (MemoryStream ms = new MemoryStream(buffer, 0, buffer.Length)) {
						string blobId = Convert.ToBase64String(Encoding.UTF8.GetBytes(Guid.NewGuid().ToString()));
						blockblob.PutBlockAsync(blobId, ms, null, null, requestoptions, null).GetAwaiter().GetResult();
						blobIdList.Add(blobId);
						File.AppendAllLines(flagFile, new List<string>() { blobId });
					}
				}
				await blockblob.PutBlockListAsync(blobIdList, null, requestoptions2, null);
			}
			catch (Exception e) {
				Console.WriteLine(e.Message);
			}
		}

		internal static Func<byte[], string> md5()
		{
			var hashFunction = MD5.Create();

			return (content) => Convert.ToBase64String(hashFunction.ComputeHash(content));
		}
	}
}